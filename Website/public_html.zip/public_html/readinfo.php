<?php
$process = "create";
$username = "id21660452_rupeshkumar29";
$password = "Rupeshkumar@29";
$dbname = "id21660452_hello";
$servername = "localhost";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
if ($process == "create"){
    $sql = "SELECT * FROM information;";
    $result = mysqli_query($conn,$sql);
    $resultcheck = mysqli_num_rows($result);

    if($resultcheck > 0){
      while($row = mysqli_fetch_assoc($result)){
        echo $row['facts'] . "+";
      }
    }
}

$conn->close();
?>