<?php
$process = "create";
$facts = $_GET['info'];;
$username = "id21660452_rupeshkumar29";
$password = "Rupeshkumar@29";
$dbname = "id21660452_hello";
$servername = "localhost";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
if ($process == "create"){
    $sql = "INSERT INTO information (facts)
    VALUES ($facts)";

    if ($conn->query($sql) === TRUE) {
        $hello = "asdf";
    }   
    else {
    }

}

$conn->close();
?>